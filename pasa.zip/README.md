# pasa-master
This is the best hacking tool for facebook....,,,
apt update 
&& uprade -y 
&& apt install git -y 
&& pkg install python2 -y 
&& git clone https://github.com/labibhacker/pasa-master
&& cd pasa 
&& unzip pasa.zip 
&& bash pasa.sh
