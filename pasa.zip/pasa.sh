clear
echo
echo -e "\e[4;31m LAC !!! \e[0m"
echo -e "\e[1;34m Presents \e[0m"
echo -e "\e[1;32m FB FUCKER \e[0m"
echo "Press Enter To Continue"
read a1
clear
echo -e "\e[1;31m"
figlet PASA
echo -e "\e[1;34m Created By \e[1;32m"
toilet -f mono12 -F border FB
toilet -f mono12 -F border FUCKER
echo -e "\e[4;34m This Bomber Was Created By SpeedX \e[0m"
echo -e "\e[1;34m For Any Queries Mail Me!!!\e[0m"
echo -e "\e[1;32m           Mail: legends.and.criminal@gmail.com \e[0m"
echo -e "\e[4;32m   YouTube Page: https://github.com/labibhacker \e[0m"
echo " "
echo -e "\e[4;31m Please Read Instruction Carefully !!! \e[0m"
echo " "
echo "Press 1 To  Start Hack-fb "
echo "Press 2 To  Start Fb King [BRUTE FORCE] "
echo "Press 3 To  Start FB FUCK "
echo "Press 4 To  Start FB KING"
echo "Press 5 To  Install All Pkg "
echo "Press 6 To  Exit"
read ch
if [ $ch -eq 1 ];then
clear
echo -e "\e[1;32m"
cd v1
bash Data-eater.sh
exit 0
python2 darkfb.py
elif [ $ch -eq 2 ];then
clear
echo -e "\e[1;32m"
echo 'Lac'
cd v1
bash Data-eater.sh
exit 0
python2 darkfb.py
elif [ $ch -eq 3 ];then
clear
cd v1
bash Data-eater.sh
exit 0
elif [ $ch -eq 4 ];then
cd v1
bash Data-eater.sh
exit 0
python2 darkfb.py
exit 0
elif [ $ch -eq 5 ];then
clear
bash Data-eater.sh
python2 darkfb.py
exit 0
python2 darkfb.py
elif [ $ch -eq 6 ];then
clear
echo -e "\e[1;31m"
figlet PASA
echo -e "\e[1;34m Created By \e[1;32m"
toilet -f mono12 -F border FB
toilet -f mono12 -F border FUCKER
echo -e "\e[1;34m For Any Queries Mail Me!!!\e[0m"
echo -e "\e[1;32m           Mail: legends.and.criminal@gmail.com \e[0m"
echo -e "\e[1;32m       Facebook: https://www.facebook.com/THE.KING.IN.MEDIA.42 \e[0m"
echo -e "\e[4;32m   Special Thanks To Labib \e[0m"
echo " "
exit 0
else
echo -e "\e[4;32m Invalid Input !!! \e[0m"
echo "Press Enter To Go Home"
read a3
clear
fi
done